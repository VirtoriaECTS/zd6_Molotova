package com.example.testmolotova

import androidx.test.ext.junit.runners.AndroidJUnit4
import junit.extensions.ActiveTestSuite

import org.junit.Rule
import org.junit.Test
import android.support.ActiveTestRule
import org.junit.rules.TestRule
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LoginActivityTest {


    @Rule
    @JvmField
    var activityRule = ActiveTestRule<LoginActivity>(LoginActivity::class.java)

    @Test
    fun testLoginSuccess() {
        // Ввод правильных данных
        // ...

        // Нажатие на кнопку входа
        // ...

        // Проверка, что отображается текст успешного входа
        // ...
    }

    @Test
    fun testLoginFailure() {
        // Ввод неправильных данных
        // ...

        // Нажатие на кнопку входа
        // ...

        // Проверка, что отображается текст неудачного входа
        // ...
    }
}
