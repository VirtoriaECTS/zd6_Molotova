package com.example.testmolotova

import android.content.Context
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
    @Test
    @Throws(Exception::class)
    fun addition_correct() {
        assertEquals(4, 2 + 2)
    }

    @Test
    @Throws(Exception::class)
    fun addition_isNotCorrect() {
        assertEquals("Numbers isn't equals!", 5, 2 + 2)
    }

    

}